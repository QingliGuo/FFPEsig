In this 'Source Data' folder, we provided all source data used in our manuscript entitled "The mutational signatures of formalin fixation on the human genome".

- We classified the source data based on the Figure index. For example, folder "Fig_1_S1_S2_S4_S6_Table_S2_S4_source_data" contains source data used in Fig 1, Fig S1, S2, S4, S6, Supplementary Table 2 and 4.
- The unclassified source data are also available in https://github.com/QingliGuo/FFPEsig/tree/main/Data
- Please also note that we shared our full analysis codes (Jupyter Notebooks), which are avaiable via this link: https://github.com/QingliGuo/FFPEsig.
- Using the souce data as well as our analysis codes, reproducing our results is straightforward.
